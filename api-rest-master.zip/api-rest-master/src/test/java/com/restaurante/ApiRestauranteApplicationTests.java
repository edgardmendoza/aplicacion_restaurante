package com.restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
