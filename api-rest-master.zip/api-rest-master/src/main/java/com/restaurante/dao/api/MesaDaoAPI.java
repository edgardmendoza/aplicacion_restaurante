package com.restaurante.dao.api;

import org.springframework.data.repository.CrudRepository;

import com.restaurante.model.Mesa;

public interface MesaDaoAPI extends CrudRepository<Mesa, Integer>{

}
