package com.restaurante.dao.api;

import org.springframework.data.repository.CrudRepository;

import com.restaurante.model.Estado;

public interface EstadoDaoAPI extends CrudRepository<Estado, Integer>{

}
