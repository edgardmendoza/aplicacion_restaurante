package com.restaurante.service.api;

import com.restaurante.commons.GenericServiceAPI;
import com.restaurante.model.Sede;

public interface SedeServiceAPI extends GenericServiceAPI<Sede, Integer>{

}
