package com.restaurante.service.api;

import com.restaurante.commons.GenericServiceAPI;
import com.restaurante.model.Estado;

public interface EstadoServiceAPI extends GenericServiceAPI<Estado, Integer>{

}
