package com.restaurante.service.api;

import com.restaurante.commons.GenericServiceAPI;
import com.restaurante.model.Empleado;

public interface EmpleadoServiceAPI extends GenericServiceAPI<Empleado, Integer>{

}
